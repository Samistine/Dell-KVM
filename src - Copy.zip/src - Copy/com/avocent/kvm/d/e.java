// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.d;

public class e {

    char[] a;
    int[] b;
    int[] c;
    char[] d;

    public e() {
        this.a = new char[17];
        this.b = new int[17];
        this.c = new int[17];
        this.d = new char[65536];
    }
}
