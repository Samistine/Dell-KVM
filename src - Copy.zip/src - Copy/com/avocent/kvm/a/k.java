// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.a;

public interface k {

    void a(int p0, int p1, String p2);
}
