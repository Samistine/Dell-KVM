// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.a.a;

public abstract class h extends b {

    protected boolean i;

    public h(final int n) {
        super(n);
        this.i = false;
    }

    @Override
    public boolean c() {
        return this.i;
    }
}
