// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.a.a;

public class v extends u {

    public v() {
        this.a(257);
        this.r = false;
    }
}
