// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.a.a;

public class k extends h {

    protected String j;

    public k(final int n, final String j) {
        super(n);
        this.e = 16;
        this.j = j;
    }

    @Override
    public void a(final byte[] array, final byte[] array2) {
    }

    @Override
    public String e() {
        return this.j;
    }

    @Override
    public byte[] b() {
        return new byte[8];
    }
}
