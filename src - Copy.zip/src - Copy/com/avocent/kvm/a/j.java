// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.a;

public class j {

    protected String a;
    protected int b;
    protected String c;

    public void a(final String a) {
        this.a = a;
    }

    public void a(final int b) {
        this.b = b;
    }

    public void b(final int b) {
        this.b = b;
    }

    public void b(final String c) {
        this.c = c;
    }
}
