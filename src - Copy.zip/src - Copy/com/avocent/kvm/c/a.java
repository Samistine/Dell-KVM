// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.c;

public interface a {

    public static final Integer a = new Integer(0);
    public static final Integer b = new Integer(1);
    public static final Integer c = new Integer(2);
    public static final Integer d = new Integer(3);
}
