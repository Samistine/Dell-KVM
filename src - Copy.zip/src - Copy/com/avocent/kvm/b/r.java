// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b;

import com.avocent.kvm.b.f.e;

public interface r {

    void a(u p0, hb p1);

    void a(u p0);

    void a(hb p0, e p1);

    void a();

    void a(hb p0, boolean p1);

    void a(boolean p0);
}
