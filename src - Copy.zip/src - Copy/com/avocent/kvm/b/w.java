// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b;

import com.avocent.kvm.b.d.c;

public interface w {

    void a(c p0);
}
