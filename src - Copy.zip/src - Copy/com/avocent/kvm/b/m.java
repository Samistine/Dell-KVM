// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b;

class m implements Runnable {

    final ob a;

    m(final ob a) {
        this.a = a;
    }

    @Override
    public void run() {
        this.a.f();
    }
}
