// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b;

import com.avocent.kvm.b.f.a;
import java.io.IOException;

public interface db {

    fb c();

    void a(fb p0);

    void a(int p0, byte[] p1, int p2);

    int d() throws IOException, kb;

    void a(boolean p0);

    void a(a p0);

    void a(eb p0);

    int e();
}
