// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.b;

import java.io.IOException;
import java.io.OutputStream;
import java.io.DataOutputStream;

public class b extends DataOutputStream {

    public b(final OutputStream outputStream) {
        super(outputStream);
    }

    @Override
    public void write(final byte[] array) throws IOException {
        super.write(array);
    }

    @Override
    public void write(final byte[] array, final int n, final int n2) throws IOException {
        super.write(array, n, n2);
    }
}
