// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b;

public interface t {

    public static final Integer a = new Integer(0);
    public static final Integer b = new Integer(1);
    public static final Integer c = new Integer(2);
    public static final Integer d = new Integer(3);
    public static final Integer e = new Integer(4);
    public static final Integer f = new Integer(0);
    public static final Integer g = new Integer(1);
    public static final Integer h = new Integer(3);
    public static final Integer i = new Integer(4);
    public static final Integer j = new Integer(5);
    public static final Integer k = new Integer(6);
    public static final Integer l = new Integer(7);
    public static final Integer m = new Integer(9);
    public static final Integer n = new Integer(12);
    public static final Integer o = new Integer(15);
}
