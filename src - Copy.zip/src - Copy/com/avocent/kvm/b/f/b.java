// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.f;

public class b {

    protected static e a;
    public static int b;

    public static e a() {
        if (com.avocent.kvm.b.f.b.a == null) {
            com.avocent.kvm.b.f.b.a = new d();
        }
        return com.avocent.kvm.b.f.b.a;
    }
}
