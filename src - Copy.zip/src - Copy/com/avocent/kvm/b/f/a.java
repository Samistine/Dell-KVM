// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.f;

public interface a {
}
