// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.d;

import java.io.IOException;

public interface c {

    byte[] a();

    byte[] b();

    void a(byte[] p0, byte[] p1) throws IOException;

    void a(byte[] p0, byte[] p1, int p2) throws IOException;

    void a(boolean p0);

    boolean c();

    int d();

    String e();

    int f();
}
