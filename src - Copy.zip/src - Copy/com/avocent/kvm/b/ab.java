// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b;

import java.beans.PropertyChangeEvent;
import com.avocent.kvm.b.a.a;

class ab implements a {

    final x a;

    ab(final x a) {
        this.a = a;
    }

    @Override
    public void a(final u u) {
        this.a.a = true;
    }

    @Override
    public void a(final u u, final db db) {
    }

    @Override
    public void a(final u u, final r r, final r r2) {
    }

    @Override
    public void b(final u u) {
    }

    @Override
    public void propertyChange(final PropertyChangeEvent propertyChangeEvent) {
    }
}
