// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.a;

import java.beans.PropertyChangeEvent;
import com.avocent.kvm.b.r;
import com.avocent.kvm.b.db;
import com.avocent.kvm.b.u;

public class b implements a {

    public static boolean a;

    @Override
    public void a(final u u) {
    }

    @Override
    public void a(final u u, final db db) {
    }

    @Override
    public void a(final u u, final r r, final r r2) {
    }

    @Override
    public void b(final u u) {
    }

    @Override
    public void propertyChange(final PropertyChangeEvent propertyChangeEvent) {
    }
}
