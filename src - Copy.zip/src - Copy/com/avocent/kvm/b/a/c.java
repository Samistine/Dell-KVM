// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.a;

import com.avocent.kvm.b.db;
import com.avocent.kvm.b.eb;

public interface c {

    void a(eb p0);

    void a(eb p0, db p1);

    void b(eb p0);
}
