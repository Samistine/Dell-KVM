// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.a;

public interface d {

    boolean a(int p0);

    boolean b(int p0);
}
