// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.kvm.b.a;

import com.avocent.kvm.b.r;
import com.avocent.kvm.b.db;
import com.avocent.kvm.b.u;
import java.beans.PropertyChangeListener;

public interface a extends PropertyChangeListener {

    void a(u p0);

    void a(u p0, db p1);

    void a(u p0, r p1, r p2);

    void b(u p0);
}
