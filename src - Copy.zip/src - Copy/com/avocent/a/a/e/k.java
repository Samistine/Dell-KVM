// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.a.a.e;

import javax.swing.JPanel;

public interface k {

    void a();

    void b();

    void c();

    JPanel d();

    String e();

    void a(c p0);

    boolean f();
}
