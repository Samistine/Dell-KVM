// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.a.a.c;

public class c {

    protected int a;
    protected boolean b;

    public c(final int a, final boolean b) {
        this.a = a;
        this.b = b;
    }

    public int a() {
        return this.a;
    }

    public boolean b() {
        return this.b;
    }
}
