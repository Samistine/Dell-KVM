// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.a.c;

public class a {

    protected b a;
    protected String b;

    public a(final String b) {
        this.b = b;
    }

    public void a(final b a) {
        this.a = a;
    }

    public void a() {
        this.a.a();
    }
}
