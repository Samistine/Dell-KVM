// 
// Decompiled by Procyon v0.5.29
// 
package com.avocent.a;

class i implements Runnable {

    final k a;

    i(final k a) {
        this.a = a;
    }

    @Override
    public void run() {
        this.a.b.a();
    }
}
