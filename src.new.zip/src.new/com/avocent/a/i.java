package com.avocent.a;

class i implements Runnable
{
    final k a;
    
    i(final k a) {
        this.a = a;
        super();
    }
    
    public void run() {
        this.a.b.a();
    }
}
