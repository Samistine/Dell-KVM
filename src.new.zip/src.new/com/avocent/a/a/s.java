package com.avocent.a.a;

import javax.swing.JFrame;
import com.avocent.kvm.b.bb;
import java.awt.Component;
import com.avocent.a.f;
import com.avocent.kvm.b.r;
import com.avocent.kvm.b.hb;

public interface s
{
    hb a(String p0);
    
    r a(Object p0);
    
    f a(i p0);
    
    bb a(i p0, Component p1);
    
    JFrame b(i p0);
    
    JFrame c(i p0);
    
    m a();
}
