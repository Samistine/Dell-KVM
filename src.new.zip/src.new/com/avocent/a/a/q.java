package com.avocent.a.a;

import com.avocent.kvm.b.f.b;

public class q
{
    public static void a(final String s) {
        b.a().a(s);
    }
}
