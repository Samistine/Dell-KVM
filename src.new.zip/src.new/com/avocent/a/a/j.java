package com.avocent.a.a;

import javax.swing.Action;
import com.avocent.a.a.a.g;
import com.avocent.a.a.a.f;
import com.avocent.a.a.a.i;
import com.avocent.a.a.a.k;
import com.avocent.a.a.a.h;
import com.avocent.a.a.a.e;
import com.avocent.a.a.a.j;
import com.avocent.a.a.a.b;
import com.avocent.a.a.a.c;
import com.avocent.a.a.a.d;

public class j
{
    protected d a;
    protected c b;
    protected b c;
    protected j d;
    protected e e;
    protected h f;
    protected k g;
    protected i h;
    protected f i;
    protected g j;
    
    public j(final i i) {
        super();
        this.a = new d(i);
        this.b = new c(i);
        this.c = new b(i);
        this.d = new j(i);
        this.e = new e(i);
        this.f = new h(i);
        this.g = new k(i);
        this.h = new i(i);
        this.i = new f(i);
        this.j = new g(i);
    }
    
    public c a() {
        return this.b;
    }
    
    public b b() {
        return this.c;
    }
    
    public j c() {
        return this.d;
    }
    
    public e d() {
        return this.e;
    }
    
    public h e() {
        return this.f;
    }
    
    public k f() {
        return this.g;
    }
    
    public Action g() {
        return this.a;
    }
    
    public Action h() {
        return this.h;
    }
    
    public Action i() {
        return this.i;
    }
    
    public Action j() {
        return this.j;
    }
}
