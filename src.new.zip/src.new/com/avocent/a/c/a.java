package com.avocent.a.c;

public class a
{
    protected b a;
    protected String b;
    
    public a(final String b) {
        super();
        this.b = b;
    }
    
    public void a(final b a) {
        this.a = a;
    }
    
    public void a() {
        this.a.a();
    }
}
