package com.avocent.a.c;

public interface b
{
    void a();
}
