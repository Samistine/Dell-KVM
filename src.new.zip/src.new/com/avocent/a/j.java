package com.avocent.a;

public interface j
{
    void a();
}
