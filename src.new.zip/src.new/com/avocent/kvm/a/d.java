package com.avocent.kvm.a;

public interface d
{
    public static final Integer a = new Integer(0);
    public static final Integer b = new Integer(1);
    public static final Integer c = new Integer(2);
    public static final Integer d = new Integer(3);
    public static final Integer e = new Integer(4);
    public static final Integer f = new Integer(10);
    public static final Integer g = new Integer(100);
}
