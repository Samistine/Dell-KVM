package com.avocent.kvm.a;

import java.beans.PropertyChangeListener;

public interface c extends PropertyChangeListener
{
}
