package com.avocent.kvm.a.a;

public class k extends h
{
    protected String j;
    
    public k(final int n, final String j) {
        super(n);
        this.e = 16;
        this.j = j;
    }
    
    public void a(final byte[] array, final byte[] array2) {
    }
    
    public String e() {
        return this.j;
    }
    
    public byte[] b() {
        return new byte[8];
    }
}
