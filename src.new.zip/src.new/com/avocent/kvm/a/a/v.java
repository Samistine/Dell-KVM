package com.avocent.kvm.a.a;

public class v extends u
{
    public v() {
        super();
        this.a(257);
        this.r = false;
    }
}
