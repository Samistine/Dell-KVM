package com.avocent.kvm.a.a;

import java.io.IOException;

public abstract class y extends b
{
    static int i;
    
    public y(final int n) {
        super(n);
    }
    
    public void a(final byte[] array, final byte[] array2) throws IOException {
    }
    
    static {
        y.i = 0;
    }
}
