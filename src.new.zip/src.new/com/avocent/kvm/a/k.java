package com.avocent.kvm.a;

public interface k
{
    void a(int p0, int p1, String p2);
}
