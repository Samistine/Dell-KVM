package com.avocent.kvm.b;

import com.avocent.kvm.b.f.c;
import java.awt.image.ColorModel;

public interface fb
{
    void a(cb p0);
    
    void b(cb p0);
    
    void a();
    
    void b();
    
    int c();
    
    int d();
    
    Object e();
    
    ColorModel f();
    
    int g();
    
    void a(boolean p0);
    
    c h();
}
