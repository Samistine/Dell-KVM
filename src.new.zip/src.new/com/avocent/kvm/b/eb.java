package com.avocent.kvm.b;

public interface eb
{
    void a(db p0);
    
    u a();
    
    void b();
    
    void c();
    
    gb d();
    
    void a(gb p0);
    
    void a(int p0);
    
    long e();
    
    long f();
    
    int g();
    
    int h();
    
    void i();
}
