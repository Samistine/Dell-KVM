package com.avocent.kvm.b;

import com.avocent.kvm.b.f.e;
import com.avocent.kvm.b.a.a;
import java.io.IOException;

public interface u
{
    void a() throws IOException;
    
    eb b();
    
    fb c();
    
    ib d();
    
    jb e();
    
    void a(a p0);
    
    void b(a p0);
    
    void f() throws IOException;
    
    void a(r p0);
    
    r g();
    
    bb h();
    
    void a(boolean p0);
    
    void a(String p0, Object p1);
    
    Object a(String p0);
    
    Integer a(String p0, Integer p1);
    
    String b(String p0);
    
    void a(String p0, Object p1, Object p2);
    
    e i();
    
    int a(int p0, Object p1, Object p2) throws IOException;
}
