package com.avocent.kvm.b;

public class kb extends RuntimeException
{
}
