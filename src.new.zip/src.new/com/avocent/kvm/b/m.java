package com.avocent.kvm.b;

class m implements Runnable
{
    final ob a;
    
    m(final ob a) {
        this.a = a;
        super();
    }
    
    public void run() {
        this.a.f();
    }
}
