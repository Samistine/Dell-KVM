package com.avocent.kvm.b.d;

import java.io.OutputStream;
import com.avocent.kvm.b.u;

public class f extends e
{
    public f() {
        super(null, null, 0, 0);
    }
    
    public void a(final d d) {
    }
    
    public synchronized void a(final int n) {
    }
    
    protected void a(final Throwable t) {
        t.printStackTrace();
    }
}
