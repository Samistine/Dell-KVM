package com.avocent.kvm.b.d;

public interface d extends c
{
    int g();
    
    int h();
    
    int i();
    
    boolean a(d p0);
}
