package com.avocent.kvm.b.f;

public interface e
{
    void a(boolean p0);
    
    boolean a();
    
    void b(boolean p0);
    
    void a(String p0);
    
    void a(String p0, String p1);
}
