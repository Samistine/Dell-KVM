package com.avocent.kvm.b.f;

public class b
{
    protected static e a;
    public static int b;
    
    public static e a() {
        if (b.a == null) {
            b.a = new d();
        }
        return b.a;
    }
}
