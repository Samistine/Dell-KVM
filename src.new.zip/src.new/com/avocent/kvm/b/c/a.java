package com.avocent.kvm.b.c;

public interface a
{
}
