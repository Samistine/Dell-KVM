package com.avocent.kvm.b;

import com.avocent.kvm.b.a.d;
import java.io.IOException;

public interface ib
{
    void a(int p0) throws IOException;
    
    void b(int p0) throws IOException;
    
    void a(d p0);
}
