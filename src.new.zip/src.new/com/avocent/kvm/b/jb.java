package com.avocent.kvm.b;

import java.io.IOException;

public interface jb
{
    void a() throws IOException;
    
    void a(int p0, int p1) throws IOException;
    
    void b(int p0, int p1) throws IOException;
    
    void c(int p0, int p1) throws IOException;
    
    void d(int p0, int p1) throws IOException;
    
    void a(int p0, int p1, int p2, boolean p3, boolean p4, boolean p5, int p6) throws IOException;
    
    void b(int p0, int p1, int p2, boolean p3, boolean p4, boolean p5, int p6) throws IOException;
    
    void c(int p0, int p1, int p2, boolean p3, boolean p4, boolean p5, int p6) throws IOException;
    
    void d(int p0, int p1, int p2, boolean p3, boolean p4, boolean p5, int p6) throws IOException;
}
