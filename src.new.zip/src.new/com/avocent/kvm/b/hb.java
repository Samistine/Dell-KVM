package com.avocent.kvm.b;

import java.awt.image.RenderedImage;
import java.awt.Component;

public interface hb
{
    Component c();
    
    void a(boolean p0);
    
    RenderedImage d();
    
    void a(String p0);
    
    void a(u p0);
    
    String getName();
    
    void b(boolean p0);
}
