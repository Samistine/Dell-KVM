package com.avocent.kvm.b;

public interface cb
{
    void a(int p0, int p1);
    
    void a();
    
    void a(int p0, int p1, int p2, int p3);
    
    void b();
}
