package com.avocent.kvm.b.a;

public interface d
{
    boolean a(int p0);
    
    boolean b(int p0);
}
