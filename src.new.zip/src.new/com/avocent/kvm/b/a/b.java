package com.avocent.kvm.b.a;

import java.beans.PropertyChangeEvent;
import com.avocent.kvm.b.r;
import com.avocent.kvm.b.db;
import com.avocent.kvm.b.u;

public class b implements a
{
    public static boolean a;
    
    public void a(final u u) {
    }
    
    public void a(final u u, final db db) {
    }
    
    public void a(final u u, final r r, final r r2) {
    }
    
    public void b(final u u) {
    }
    
    public void propertyChange(final PropertyChangeEvent propertyChangeEvent) {
    }
}
