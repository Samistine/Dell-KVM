package com.avocent.kvm.b.e;

import javax.swing.JFrame;
import com.avocent.kvm.b.f.e;
import com.avocent.kvm.b.u;

public interface a
{
    u a();
    
    void a(String p0);
    
    e b();
    
    String a(String p0, String p1);
    
    String b(String p0);
    
    JFrame c();
}
