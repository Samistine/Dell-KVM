package com.avocent.kvm.b;

import java.beans.PropertyChangeEvent;
import com.avocent.kvm.b.a.a;

class ab implements a
{
    final x a;
    
    ab(final x a) {
        this.a = a;
        super();
    }
    
    public void a(final u u) {
        this.a.a = true;
    }
    
    public void a(final u u, final db db) {
    }
    
    public void a(final u u, final r r, final r r2) {
    }
    
    public void b(final u u) {
    }
    
    public void propertyChange(final PropertyChangeEvent propertyChangeEvent) {
    }
}
